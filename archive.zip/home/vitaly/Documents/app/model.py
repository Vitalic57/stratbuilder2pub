from basemodel import BaseModel
import numpy 

class Model(BaseModel):
    
    def __init__(self):
        self.prev = 0
        self.preprev = 0
    
    def init(self, x):
        self.preprev = x[-2][0]
        self.prev = x[-1][0]
    
    def predict(self):
        if self.prev > self.preprev:
            return 0.
        else:
            return 1.

    def step(self, x):
        self.prev = x[0]
        self.preprev = self.prev
        
